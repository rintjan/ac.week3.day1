package com.accenture.bootcamp.day1

import java.io.File

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

object Loader {

  protected def fromResource(resource: String): String = {
   //new File("C:\\Users\\Student\\Desktop\\spark task\\bigdata\\src\\test\\resources\\" + resource).toURI.toString
    //new File(new File(".").getCanonicalPath).toURI.toString + "test/resources/" + resource
    //new File(new File("test/resources/" + resource).getCanonicalPath).toURI.toString
    new File(new File("src\\test\\resources\\" + resource).getCanonicalPath).toURI.toString
  }

  def loadNewYearHonours(sc: SparkContext): RDD[String] = {
    // TODO Task #1: Create RDD from file `1918NewYearHonours.txt`
    val filePath = fromResource("1918NewYearHonours.txt")
    val rdd_1 = sc.textFile(filePath)
    rdd_1
  }

  def loadAustralianTreaties(sc: SparkContext): RDD[String] = {
    // TODO Task #2: Create RDD from file `ListOfAustralianTreaties.txt`
    val filePath = fromResource("ListOfAustralianTreaties.txt")
    val rdd_2 = sc.textFile(filePath)
    rdd_2
  }


}
